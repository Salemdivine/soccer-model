# soccer-model

Shots-on-target Poisson model that turns past results into win/draw/loss
probabilities. Built from the notebook work: time decay (half-life 180 days),
shrinkage (k = 8), shots on target blended into goal equivalents.

**Honest note:** backtests against Bet365 odds showed this model adds no
information beyond the bookmaker. Use it to learn and as a rough guide, not
as a betting tool.

## Install

On your own machine (needs Python 3.9+):

    cd soccer-model
    pip install -e .

The `-e` means "editable": any change you make to the code takes effect
immediately, with no reinstall.

On any other machine or Colab (after you push this folder to GitHub):

    pip install git+https://github.com/YOUR-USERNAME/soccer-model.git

## Use

1. Put your football-data.co.uk CSVs (E0, E1, E2, E3, EC, any seasons) in `data/`.
2. Train and save the model:

       soccer-model fit --data data --out model.json

3. Predict a match (division is detected from the home team):

       soccer-model predict "Crawley Town" "Chesterfield"

4. See team names the model knows:

       soccer-model teams

5. Re-run the date-based backtest against bookmaker odds:

       soccer-model evaluate --data data

Re-download the current-season CSVs and re-run step 2 whenever you want fresh ratings.

## Upgrade the model

All the maths lives in `soccer_model/model.py`. To improve it:

1. Edit `model.py` (for example add total shots or corners into `fit`).
2. Run `soccer-model evaluate --data data` and keep the change only if the
   model's log loss goes down.
3. Bump `version` in `pyproject.toml` and `soccer_model/__init__.py`.
4. Save the change with git:

       git add . && git commit -m "describe the change" && git push

5. On any other machine: `pip install --upgrade git+https://github.com/YOUR-USERNAME/soccer-model.git`

## Files

    soccer_model/data.py    loads the CSV files
    soccer_model/model.py   fit, predict, evaluate, save/load
    soccer_model/cli.py     the soccer-model command
    tests/test_model.py     quick checks (run with: python -m pytest)
