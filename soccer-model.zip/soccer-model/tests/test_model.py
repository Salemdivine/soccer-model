import numpy as np
import pandas as pd

from soccer_model.data import load_folder
from soccer_model.model import Model, evaluate, fit, predict


def make_csv(path, seed=0, teams=("Ayr", "Bath", "Cork", "Derby", "Eton", "Fife")):
    """Fake football-data-style season: stronger teams (earlier in list) score more."""
    rng = np.random.default_rng(seed)
    strength = {t: 1.6 - 0.2 * i for i, t in enumerate(teams)}
    rows = []
    day = pd.Timestamp("2024-08-01")
    for _ in range(4):
        for h in teams:
            for a in teams:
                if h == a:
                    continue
                hg = rng.poisson(max(0.3, strength[h] * 0.9))
                ag = rng.poisson(max(0.3, strength[a] * 0.7))
                hst, ast = hg * 3 + rng.integers(0, 4), ag * 3 + rng.integers(0, 4)
                ftr = "H" if hg > ag else "A" if ag > hg else "D"
                rows.append(dict(Div="E1", Date=day.strftime("%d/%m/%Y"), HomeTeam=h, AwayTeam=a,
                                 FTHG=hg, FTAG=ag, FTR=ftr, HST=hst, AST=ast,
                                 B365H=2.2, B365D=3.3, B365A=3.4))
                day += pd.Timedelta(days=1)
    pd.DataFrame(rows).to_csv(path, index=False)


def test_fit_predict_save_load(tmp_path):
    make_csv(tmp_path / "E1.csv")
    df = load_folder(tmp_path)
    model = fit(df)
    r = predict(model, "Ayr", "Fife")
    assert abs(r["p_home"] + r["p_draw"] + r["p_away"] - 1) < 0.01
    assert r["p_home"] > r["p_away"]            # strongest team at home should be favoured

    model.save(tmp_path / "m.json")
    r2 = predict(Model.load(tmp_path / "m.json"), "Ayr", "Fife")
    assert r2["p_home"] == r["p_home"]


def test_unknown_team_gives_helpful_error(tmp_path):
    make_csv(tmp_path / "E1.csv")
    model = fit(load_folder(tmp_path))
    try:
        predict(model, "Ayrr", "Fife")
    except ValueError as e:
        assert "Ayr" in str(e)
    else:
        raise AssertionError("expected ValueError")


def test_evaluate_runs(tmp_path):
    make_csv(tmp_path / "E1.csv")
    r = evaluate(load_folder(tmp_path))
    assert r["model"] is not None and r["bookmaker"] is not None
