"""Load football-data.co.uk CSV files from a folder into one clean DataFrame."""

from pathlib import Path

import numpy as np
import pandas as pd

REQUIRED = ["Div", "Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG", "FTR"]
OPTIONAL = ["HST", "AST", "B365H", "B365D", "B365A"]


def load_folder(folder):
    """Read every .csv in `folder` and return one DataFrame sorted by date.

    Columns returned: Div, Date, Home, Away, hg, ag, FTR, HST, AST, B365H, B365D, B365A
    """
    folder = Path(folder)
    files = sorted(folder.glob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No .csv files found in {folder.resolve()}")

    frames = []
    for f in files:
        d = pd.read_csv(f, encoding="latin-1", on_bad_lines="skip")
        missing = [c for c in REQUIRED if c not in d.columns]
        if missing:
            print(f"Skipping {f.name}: missing columns {missing}")
            continue
        for c in OPTIONAL:
            if c not in d.columns:
                d[c] = np.nan
        frames.append(d[REQUIRED + OPTIONAL])

    if not frames:
        raise ValueError("No usable CSV files (see messages above).")

    df = pd.concat(frames, ignore_index=True)
    df["Date"] = pd.to_datetime(df["Date"], dayfirst=True, format="mixed", errors="coerce")
    df = df.rename(columns={"HomeTeam": "Home", "AwayTeam": "Away", "FTHG": "hg", "FTAG": "ag"})
    df = df.dropna(subset=["Date", "Home", "Away", "hg", "ag", "FTR"])
    return df.sort_values("Date").reset_index(drop=True)
