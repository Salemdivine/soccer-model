"""Soccer match probability model (shots-on-target Poisson model)."""

__version__ = "0.1.0"
