"""Command-line interface: soccer-model fit | predict | evaluate | teams"""

import argparse
import sys

from . import __version__
from .data import load_folder
from .model import HALF_LIFE, K, Model, evaluate, fit, predict


def _fit(a):
    df = load_folder(a.data)
    model = fit(df, a.half_life, a.k)
    model.save(a.out)
    print(f"Trained on {model.n_matches} matches up to {model.trained_through}.")
    print(f"{len(model.att)} teams. Saved to {a.out}")


def _predict(a):
    model = Model.load(a.model)
    r = predict(model, a.home, a.away, a.div)
    print(f"{r['home']} vs {r['away']}  ({r['div']})")
    print(f"Expected goals: {r['expected_goals'][0]} - {r['expected_goals'][1]}")
    print(f"Home win {r['p_home']:.1%} | Draw {r['p_draw']:.1%} | Away win {r['p_away']:.1%}")
    print(f"(model trained through {model.trained_through})")


def _evaluate(a):
    df = load_folder(a.data)
    r = evaluate(df, a.train_frac, a.half_life, a.k)
    print(f"Test matches: {r['n_test']} ({r['n_with_odds']} with odds)")
    if r["model"] is None:
        print("No odds columns found, so no bookmaker comparison is possible.")
        return
    print(f"Model log loss:     {r['model']:.4f}")
    print(f"Bookmaker log loss: {r['bookmaker']:.4f}")
    print(f"Gap (model - bookmaker): {r['model'] - r['bookmaker']:+.4f}  (lower log loss is better)")


def _teams(a):
    model = Model.load(a.model)
    for t in sorted(model.att):
        print(f"{t}  [{model.team_div[t]}]")


def main(argv=None):
    p = argparse.ArgumentParser(prog="soccer-model", description="Soccer match probability model")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    f = sub.add_parser("fit", help="train on a folder of CSVs and save the model")
    f.add_argument("--data", default="data", help="folder with football-data.co.uk CSVs")
    f.add_argument("--out", default="model.json")
    f.add_argument("--half-life", type=float, default=HALF_LIFE)
    f.add_argument("--k", type=float, default=K)
    f.set_defaults(func=_fit)

    q = sub.add_parser("predict", help="probabilities for one match")
    q.add_argument("home")
    q.add_argument("away")
    q.add_argument("--div", default=None, help="division code, e.g. E0 (default: home team's)")
    q.add_argument("--model", default="model.json")
    q.set_defaults(func=_predict)

    e = sub.add_parser("evaluate", help="date-based backtest vs bookmaker odds")
    e.add_argument("--data", default="data")
    e.add_argument("--train-frac", type=float, default=0.8)
    e.add_argument("--half-life", type=float, default=HALF_LIFE)
    e.add_argument("--k", type=float, default=K)
    e.set_defaults(func=_evaluate)

    t = sub.add_parser("teams", help="list team names the model knows")
    t.add_argument("--model", default="model.json")
    t.set_defaults(func=_teams)

    a = p.parse_args(argv)
    try:
        a.func(a)
    except (FileNotFoundError, ValueError) as err:
        print(f"Error: {err}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
