"""Shots-on-target Poisson model for soccer match outcome probabilities.

How it works
------------
1. Each team's attack and defence strength is measured from shots on target
   (converted to "goal equivalents" with each division's conversion rate).
2. Recent matches count more (exponential time decay, `half_life` days).
3. Ratings are shrunk toward average (`k`) so small samples don't mislead.
4. Expected goals for both sides -> independent Poisson -> P(home), P(draw), P(away).
"""

import difflib
import json
from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd
from scipy.stats import poisson

HALF_LIFE = 180   # days until a match counts half as much
K = 8             # shrinkage toward average (higher = trust a team's record less)


def outcome_probs(h_exp, a_exp, n=10):
    """Expected goals for each side -> [P(home win), P(draw), P(away win)]."""
    m = np.outer(poisson.pmf(range(n), h_exp), poisson.pmf(range(n), a_exp))
    return [float(np.tril(m, -1).sum()), float(np.trace(m)), float(np.triu(m, 1).sum())]


@dataclass
class Model:
    home_avg: dict        # avg home goals per division
    away_avg: dict        # avg away goals per division
    att: dict             # attack strength per team (1.0 = average)
    dfn: dict             # defence weakness per team (below 1.0 = good defence)
    team_div: dict        # most recent division of each team
    half_life: float
    k: float
    trained_through: str  # date of the last match used
    n_matches: int

    def save(self, path):
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=1)

    @classmethod
    def load(cls, path):
        with open(path) as f:
            return cls(**json.load(f))


def fit(df, half_life=HALF_LIFE, k=K):
    """Train on a DataFrame from data.load_folder() and return a Model."""
    tr = df.copy()

    # shots on target -> goal equivalents, using each division's conversion rate
    s = tr[tr.HST.notna() & tr.AST.notna()]
    ch = s.groupby("Div").hg.sum() / s.groupby("Div").HST.sum()
    ca = s.groupby("Div").ag.sum() / s.groupby("Div").AST.sum()
    ch = ch.replace([np.inf, -np.inf], np.nan)
    ca = ca.replace([np.inf, -np.inf], np.nan)
    tr["sh"] = (tr.HST * tr.Div.map(ch)).fillna(tr.hg)   # falls back to goals if no shots
    tr["sa"] = (tr.AST * tr.Div.map(ca)).fillna(tr.ag)

    # recent matches count more
    tr["w"] = 0.5 ** ((tr.Date.max() - tr.Date).dt.days / half_life)
    tr["whg"], tr["wag"] = tr.hg * tr.w, tr.ag * tr.w
    g = tr.groupby("Div")[["whg", "wag", "w"]].sum()
    home_avg, away_avg = g.whg / g.w, g.wag / g.w
    div_avg = (home_avg + away_avg) / 2

    # one row per team per match, measured against that division's average
    h = pd.DataFrame({"team": tr.Home, "Div": tr.Div, "gf": tr.sh, "ga": tr.sa, "w": tr.w})
    a = pd.DataFrame({"team": tr.Away, "Div": tr.Div, "gf": tr.sa, "ga": tr.sh, "w": tr.w})
    long = pd.concat([h, a])
    avg = long.Div.map(div_avg)
    long["gf_rel"] = long.gf / avg * long.w
    long["ga_rel"] = long.ga / avg * long.w
    t = long.groupby("team")[["gf_rel", "ga_rel", "w"]].sum()
    att = (t.gf_rel + k) / (t.w + k)    # shrink toward 1.0 (average)
    dfn = (t.ga_rel + k) / (t.w + k)

    # latest division of each team (so predictions don't need a division code)
    rows = pd.concat([
        tr[["Date", "Home", "Div"]].rename(columns={"Home": "team"}),
        tr[["Date", "Away", "Div"]].rename(columns={"Away": "team"}),
    ]).sort_values("Date")
    team_div = rows.groupby("team").Div.last()

    return Model(
        home_avg=home_avg.to_dict(), away_avg=away_avg.to_dict(),
        att=att.to_dict(), dfn=dfn.to_dict(), team_div=team_div.to_dict(),
        half_life=half_life, k=k,
        trained_through=str(tr.Date.max().date()), n_matches=int(len(tr)),
    )


def _check_team(model, name):
    if name not in model.att:
        close = difflib.get_close_matches(name, list(model.att), n=3, cutoff=0.5)
        hint = f" Did you mean: {', '.join(close)}?" if close else ""
        raise ValueError(f"Unknown team '{name}'.{hint}")


def predict(model, home, away, div=None):
    """Probabilities for one match. `div` defaults to the home team's division."""
    _check_team(model, home)
    _check_team(model, away)
    div = div or model.team_div[home]
    if div not in model.home_avg:
        raise ValueError(f"Unknown division '{div}'. Known: {sorted(model.home_avg)}")
    hx = model.home_avg[div] * model.att[home] * model.dfn[away]
    ax = model.away_avg[div] * model.att[away] * model.dfn[home]
    ph, pd_, pa = outcome_probs(hx, ax)
    return {"home": home, "away": away, "div": div,
            "expected_goals": (round(hx, 2), round(ax, 2)),
            "p_home": ph, "p_draw": pd_, "p_away": pa}


def _log_loss(y, probs):
    probs = np.clip(probs, 1e-15, 1)
    probs = probs / probs.sum(axis=1, keepdims=True)
    return float(-np.mean(np.log(probs[np.arange(len(y)), y])))


def evaluate(df, train_frac=0.8, half_life=HALF_LIFE, k=K):
    """Train on the first `train_frac` of matches (by date), score the rest.

    Returns log loss for the model and for the Bet365 closing-style odds
    (lower is better), on matches where odds are available.
    """
    cut = int(len(df) * train_frac)
    train, test = df.iloc[:cut], df.iloc[cut:]
    test = test[test.Home.isin(train.Home) & test.Away.isin(train.Away)]

    model = fit(train, half_life, k)
    probs = np.array([[r["p_home"], r["p_draw"], r["p_away"]]
                      for r in (predict(model, m.Home, m.Away, m.Div) for m in test.itertuples())])
    y = test["FTR"].map({"H": 0, "D": 1, "A": 2}).values

    odds_cols = ["B365H", "B365D", "B365A"]
    mask = test[odds_cols].notna().all(axis=1).values
    out = {"n_test": int(len(test)), "n_with_odds": int(mask.sum()),
           "model": _log_loss(y[mask], probs[mask]) if mask.any() else None,
           "bookmaker": None}
    if mask.any():
        implied = 1 / test.loc[mask, odds_cols].values
        out["bookmaker"] = _log_loss(y[mask], implied / implied.sum(axis=1, keepdims=True))
    return out
